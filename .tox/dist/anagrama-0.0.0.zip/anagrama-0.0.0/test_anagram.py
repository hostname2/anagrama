def test_detector_anagrama():
    return sorted('car') == sorted('racs')


assert False ==  test_detector_anagrama()
