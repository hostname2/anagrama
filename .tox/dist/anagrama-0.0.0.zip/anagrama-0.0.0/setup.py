from setuptools import setup

setup(
    name='anagrama',
    version='',
    packages=[''],
    url='',
    license='',
    author='sebas',
    author_email='',
    description=''
)
